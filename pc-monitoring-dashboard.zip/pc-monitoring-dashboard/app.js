const computers = [
  { name: "OFFICE-PC-01", owner: "Office workstation", status: "Online", cpu: 28, ram: 56, disk: 62, network: "2.4 Mbps" },
  { name: "PRODUCTION-PC-02", owner: "Production desk", status: "Online", cpu: 64, ram: 78, disk: 71, network: "8.1 Mbps" },
  { name: "STORE-PC-03", owner: "Stores workstation", status: "Offline", cpu: 0, ram: 0, disk: 48, network: "—" },
  { name: "MANAGER-PC-04", owner: "Manager workstation", status: "Online", cpu: 22, ram: 49, disk: 39, network: "1.7 Mbps" }
];

const rows = document.getElementById("computerRows");
const searchInput = document.getElementById("searchInput");
const statusFilter = document.getElementById("statusFilter");

function metric(value, label) {
  const color = value >= 85 ? "high" : value >= 70 ? "warn" : "";
  return `<div class="metric"><div class="metric-label"><span>${label}</span><strong>${value}%</strong></div><div class="metric-track"><div class="metric-fill ${color}" style="width:${value}%"></div></div></div>`;
}
function render() {
  const query = searchInput.value.trim().toLowerCase();
  const status = statusFilter.value;
  const filtered = computers.filter(pc =>
    (pc.name.toLowerCase().includes(query) || pc.owner.toLowerCase().includes(query)) &&
    (status === "all" || pc.status === status)
  );
  rows.innerHTML = filtered.map(pc => `
    <tr>
      <td><div class="computer-name"><span class="pc-icon">▣</span><div><strong>${pc.name}</strong><small>${pc.owner}</small></div></div></td>
      <td><span class="status ${pc.status.toLowerCase()}"><span class="status-dot"></span>${pc.status}</span></td>
      <td>${metric(pc.cpu, "CPU")}</td>
      <td>${metric(pc.ram, "RAM")}</td>
      <td><span class="disk-cell">${pc.disk}% used</span></td>
      <td><span class="network">${pc.network}</span></td>
    </tr>`).join("");
  document.getElementById("emptyState").classList.toggle("hidden", filtered.length !== 0);
}
function updateSummary() {
  const online = computers.filter(pc => pc.status === "Online");
  const avg = key => online.length ? Math.round(online.reduce((sum, pc) => sum + pc[key], 0) / online.length) : 0;
  const cpu = avg("cpu"), ram = avg("ram");
  document.getElementById("pcCount").textContent = computers.length;
  document.getElementById("onlineCount").textContent = online.length;
  document.getElementById("avgCpu").innerHTML = `${cpu}<span class="unit">%</span>`;
  document.getElementById("avgRam").innerHTML = `${ram}<span class="unit">%</span>`;
  document.getElementById("avgCpuBar").style.width = `${cpu}%`;
  document.getElementById("avgRamBar").style.width = `${ram}%`;
}
function exportCsv() {
  const headers = ["Computer", "Description", "Status", "CPU %", "RAM %", "Disk used %", "Network"];
  const lines = [headers, ...computers.map(pc => [pc.name, pc.owner, pc.status, pc.cpu, pc.ram, pc.disk, pc.network])];
  const csv = lines.map(line => line.map(value => `"${String(value).replaceAll('"', '""')}"`).join(",")).join("\r\n");
  const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `pc-monitor-report-${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
}
function refreshDemo() {
  // Small random variation is only for UI demonstration, not actual PC readings.
  computers.forEach(pc => {
    if (pc.status === "Online") {
      pc.cpu = Math.max(3, Math.min(95, pc.cpu + Math.round(Math.random() * 12 - 6)));
      pc.ram = Math.max(10, Math.min(95, pc.ram + Math.round(Math.random() * 8 - 4)));
    }
  });
  updateSummary(); render();
}
searchInput.addEventListener("input", render);
statusFilter.addEventListener("change", render);
document.getElementById("exportBtn").addEventListener("click", exportCsv);
document.getElementById("refreshBtn").addEventListener("click", refreshDemo);
updateSummary(); render();
